<?php $__env->startSection('headers'); ?>

<style>
.fixed-sn main {
    margin-left: 2% !important;
    margin-right: 2% !important;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Livewire Test!</h1>

    <div>
        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('livewirejunk')->dom;
} elseif ($_instance->childHasBeenRendered('NcV8XGc')) {
    $componentId = $_instance->getRenderedChildComponentId('NcV8XGc');
    $componentTag = $_instance->getRenderedChildComponentTagName('NcV8XGc');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NcV8XGc');
} else {
    $response = \Livewire\Livewire::mount('livewirejunk');
    $dom = $response->dom;
    $_instance->logRenderedChild('NcV8XGc', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo \Livewire\Livewire::assets(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cis\resources\views/livewire.blade.php ENDPATH**/ ?>