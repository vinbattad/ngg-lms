

<?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($item->full_name); ?></td>
    <td><?php echo e($item->full_name); ?></td>
    <td><?php echo e($item->full_name); ?></td>
    <td><?php echo e($item->full_name); ?></td>
    <td><?php echo e($item->full_name); ?></td>
    <td><?php echo e($item->full_name); ?></td>
    <td><?php echo e($item->full_name); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\cis\resources\views/widgets/property_listing_table.blade.php ENDPATH**/ ?>