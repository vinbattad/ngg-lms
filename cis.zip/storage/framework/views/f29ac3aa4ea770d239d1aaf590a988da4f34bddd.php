<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="d-flex">
            <div>
                <h2 style="color:#008349;"><i class="fas fa-hotel"></i> Hotel</h2>
            </div>
            <div class="ml-auto"> <a class="btn btn-success" href=<?php echo e(route('Hotel.create')); ?> id="createNewProduct"> <i
                        class="fas fa-plus-circle"></i> Create New Hotel</a> </div>
        </div>
        <hr>



    </div>


    
        <?php echo app('arrilot.async-widget')->run('hotel_branches'); ?>
    



<!--
    <div class="row">

        <div class="col-xs-3">
            <div class="card" style="width: 18rem;">
                <img src="<?php echo e(url("img/hotel.jpg")); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title" id="hotel_name"></h5>
                    <p class="card-text"></p>
                    <a href="#" class="btn btn-primary">More Details</a>
                </div>
            </div>
        </div>

    </div>
-->

</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cis\resources\views/Hotel/index.blade.php ENDPATH**/ ?>