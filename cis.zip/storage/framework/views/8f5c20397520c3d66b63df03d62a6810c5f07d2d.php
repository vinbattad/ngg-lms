





<div class="row">
    <?php $__currentLoopData = $hotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xs-3 mb-4">
        <div class="card" style="width: 18rem;">
        <img src="<?php echo e(url('hotel_images/'.$view->hotel_image)); ?>" class="card-img-top" height="200" alt="<?php echo e($view->hotel_name); ?>"
        data-toggle="tooltip" data-placement="top" title="<?php echo e($view->hotel_name); ?>">
            <div class="card-body">
                <h5 class="card-title"> <?php echo e($view->hotel_name); ?></h5>
                <p class="card-text"></p>
                <a href="#" class="btn btn-primary">More Details</a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<script>

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script><?php /**PATH C:\xampp\htdocs\cis\resources\views/widgets/hotel_branches.blade.php ENDPATH**/ ?>