<?php $__env->startSection('content'); ?>

<div class="d-flex">
    <div>
        <h2 style="color:#008349;"><i class="fas fa-building"></i> Units</h2>
    </div>
    <div class="ml-auto">
        <a class="btn btn-primary" id="createNewProduct" href=<?php echo e(route("Rooms.index",$id)); ?>> <i
                class="fas fa-arrow-circle-left"></i> Go Back</a>
    </div>
</div>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home" style="color:darkgoldenrod">&nbsp;</i><a
                href="<?php echo e('/home'); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-building"></i> Property Listing
        </li>
        <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-building"></i> Units
        </li>
        <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-building"></i> Create Units
        </li>
    </ol>
</nav>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('Rooms.store',$id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="row">
        <fieldset class="col-lg-12">
            <legend class="pl-3 text-dark"><i class="fas fa-plus-circle "></i> Create Unit</legend>

            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="text-dark">Unit Name/No.</label>
                            <input type="text" class="form-control" name="room_name" required>
                        </div>
                        <div class="form-group">
                            <label class="text-dark" hidden>Unit Name/No.</label>
                        <input type="text" class="form-control" name="id_link_property_listing" required value="<?php echo e($id); ?>" hidden>
                        </div>
                    </div>
                </div>
            </div>

        </fieldset>
    </div>


    <div class="row justify-content-end mt-2 mb-5">
        <button class="btn btn-success">Submit</button>
    </div>

</form>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cis\resources\views/Units/create.blade.php ENDPATH**/ ?>