<?php $__env->startSection('content'); ?>

show

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cis\resources\views/Hotel/show.blade.php ENDPATH**/ ?>