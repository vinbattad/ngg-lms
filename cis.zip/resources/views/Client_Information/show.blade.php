@extends('layouts.app')



@section('content')

show

@endsection