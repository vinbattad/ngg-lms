

@foreach ($property as $item)
    <tr>
    <td>{{$item->full_name}}</td>
    <td>{{$item->full_name}}</td>
    <td>{{$item->full_name}}</td>
    <td>{{$item->full_name}}</td>
    <td>{{$item->full_name}}</td>
    <td>{{$item->full_name}}</td>
    <td>{{$item->full_name}}</td>
    </tr>
@endforeach