<?php return array (
  'property-listing' => 'App\\Http\\Livewire\\PropertyListing',
);