<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Occupants_Name extends Model
{
    //
}
